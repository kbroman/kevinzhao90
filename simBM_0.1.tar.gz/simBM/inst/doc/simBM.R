## ----loadPackage---------------------------------------------------------
library(simBM)
library(knitr)

## ----Example-------------------------------------------------------------
n=1000
sigma=1

bm=simBM(n=n,sigma=sigma)
plotBM(bm)

